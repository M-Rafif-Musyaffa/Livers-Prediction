package com.example.mymechinelearning.ui.about

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class AboutViewModel : ViewModel() {

    private val teksJudul = MutableLiveData<String>().apply {
        value = "Judul Aplikasi"
    }
    val textjudul: LiveData<String> = teksJudul

    private val teksdecs = MutableLiveData<String>().apply {
        value = "Deksripsi Aplikasi"
    }
    val textdeksripsi: LiveData<String> = teksdecs
}