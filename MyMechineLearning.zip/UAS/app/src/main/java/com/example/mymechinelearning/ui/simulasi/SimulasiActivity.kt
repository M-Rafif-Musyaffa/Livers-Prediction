package com.example.mymechinelearning.ui.simulasi

import android.content.res.AssetManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.navigation.findNavController
import com.example.mymechinelearning.R
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class SimulasiActivity : AppCompatActivity() {


    private lateinit var interpreter: Interpreter
    private val mModelPath = "iris.tflite"

    private lateinit var resultText: TextView
    private lateinit var edtSepalLength: EditText
    private lateinit var edtSepalWidth: EditText
    private lateinit var edtPetalLength: EditText
    private lateinit var edtPetalWidth: EditText
    private lateinit var checkButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_simulasi)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        resultText = findViewById(R.id.txtResult)
        edtSepalLength = findViewById(R.id.editSepalLengthCm)
        edtSepalWidth = findViewById(R.id.editSepalWidthCm)
        edtPetalLength = findViewById(R.id.editPetalLengthCm)
        edtPetalWidth = findViewById(R.id.editPetalWidthCm)
        checkButton = findViewById(R.id.btnCheck)



        checkButton.setOnClickListener {
            var result = doInference(
                edtSepalLength.text.toString(),
                edtSepalWidth.text.toString(),
                edtPetalLength.text.toString(),
                edtPetalWidth.text.toString()
            )
            runOnUiThread{
                if (result == 0){
                    resultText.text = "iris-setosa"
                }else if (result == 1){
                    resultText.text = "iris-versicolor"
                }else{
                    resultText.text = "iris-virginica"
                }
            }
        }
        initInterpreter()
    }

    private fun initInterpreter(){
        val options = Interpreter.Options()
        options.setNumThreads(5)
        options.setUseNNAPI(true)
        interpreter = Interpreter(loadModelFile(assets,mModelPath),options)
    }


    private fun doInference(input1:String,input2:String,input3:String,input4:String): Int{
        val inputVal = FloatArray(4)
        inputVal[0] = input1.toFloat()
        inputVal[1] = input2.toFloat()
        inputVal[2] = input3.toFloat()
        inputVal[3] = input4.toFloat()
        val output = Array(1){FloatArray(3)}
        interpreter.run(inputVal,output)
        Log.e("result",(output[0].toList()+" ").toString())
        return output[0].indexOfFirst { it == output[0].maxOrNull() }
    }

    private fun loadModelFile(assetManager: AssetManager,modelPATH:String):MappedByteBuffer{
        val fileDescriptor = assetManager.openFd(modelPATH)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val starOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY,starOffset,declaredLength)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}